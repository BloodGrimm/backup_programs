import java.util.*;

public class Kmeans {

    List<Centroid> centroids = new ArrayList<>();

    List<Double> max = new ArrayList<>();
    List<Double> min = new ArrayList<>();

    List<Flower> data;
    public Kmeans(List<Flower> data) {
        this.data = data;
        System.out.println("Podaj K: ");
        Scanner getk = new Scanner(System.in);
        int k = getk.nextInt();
        for (int i = 0; i < data.size(); i++) {
            Flower tmp = data.get(i);
            for (int j = 0; j < tmp.atributes.size(); j++) {
                if(max.size() < tmp.atributes.size() || min.size() < tmp.atributes.size()){
                    min.add(tmp.atributes.get(j));
                    max.add(tmp.atributes.get(j));
                }else{
                    if(tmp.atributes.get(j) > max.get(j) ){
                        max.set(j, tmp.atributes.get(j));
                    }
                    if(tmp.atributes.get(j) < min.get(j)){
                        min.set(j, tmp.atributes.get(j));
                    }
                }
            }
        }
        for (int i = 0; i < k; i++) {
            Centroid centroid = new Centroid(min, max);
            centroids.add(centroid);
        }

        for (int i = 0; i < data.size(); i++) {
            Flower tmp = data.get(i);
            asignFlower(tmp);
        }
        int counter = 0;
        while (counter < 100){
            for (int i = 0; i < centroids.size(); i++) {
                int suma = 0;
                for (int j = 0; j < centroids.get(i).flowers.size(); j++) {
                    suma += centroids.get(i).getDist(centroids.get(i).flowers.get(j));
                }
                System.out.println("Suma odl dla centroid nr " + i + ":[" + suma + "]");
            }
            for(Centroid centroid:centroids)centroid.flowers=new ArrayList<>();
            for (int j = 0; j < data.size(); j++) {
                asignFlower(data.get(j));
            }
            for (int i = 0; i < centroids.size(); i++) {
                centroids.get(i).newValues();
            }
            counter += 1;
        }
        for (int i = 0; i < centroids.size(); i++) {
            System.out.println("Entropia dla centroida " + i + " : " + centroids.get(i).entropy());
        }
    }

    public void asignFlower(Flower flower){
        double dis = centroids.get(0).getDist(flower);
        Centroid best = centroids.get(0);
        for (int i = 0; i < centroids.size(); i++) {
            if(centroids.get(i).getDist(flower) < dis){
                dis = centroids.get(i).getDist(flower);
                best = centroids.get(i);
            }
        }
        best.addFlower(flower);
    }

    public void printCentroids(){
        for (int i = 0; i < centroids.size(); i++) {
            System.out.println("Grupa: " + i);
            for (int j = 0; j < centroids.get(i).flowers.size(); j++) {
                System.out.println(centroids.get(i).flowers.get(j));
            }
            System.out.println();
            System.out.println("---------------------");
            System.out.println();
        }
    }

    public void centData(List<Centroid> centroids){
        for (int i = 0; i < centroids.size(); i++) {
            System.out.println(centroids.get(i).values);
        }
    }

}