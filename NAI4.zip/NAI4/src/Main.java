import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static List<Flower> data = new ArrayList<>();

    public static void main(String[] args) {
        loadData(data);
        Kmeans kmeans = new Kmeans(data);
        kmeans.printCentroids();
    }

    public static void loadData(List<Flower> data){
        try {
            Scanner scanner = new Scanner(new File("src/iris_training.txt"));
            while (scanner.hasNext()){
                Flower tmp = new Flower(scanner.nextLine());
                data.add(tmp);
            }
        }catch (Exception e){
            System.out.println("Problem z wczytaniem danych.");
        }
    }
}
