import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Centroid {

    List<Double> values = new ArrayList<>();

    public List<Flower> flowers = new ArrayList<>();
    public Centroid(List<Double> min, List<Double> max) {
        for (int i = 0; i < min.size(); i++) {
            values.add(min.get(i) + (max.get(i) - min.get(i)) * Math.random());
        }
    }

    public void addFlower(Flower flower){
        flowers.add(flower);
    }

    public double getDist(Flower flower){
        double wynik = 0;
        List<Double> atributes = flower.getAtributes();
        for (int i = 0; i < atributes.size(); i++) {
            wynik += (Math.pow((values.get(i) - atributes.get(i)), 2));
        }
        wynik = Math.sqrt(wynik);
        return wynik;
    }

    public void newValues(){
        if(flowers.size()==0)
            return;
        List<Double> newValues = new ArrayList<>();
        for (int i=0; i<values.size();i++)newValues.add(0.0);
        for(Flower flower : flowers){
            List<Double> poz=flower.atributes;
            for(int i=0; i<poz.size();i++){
                newValues.set(i, newValues.get(i)+ poz.get(i));
            }
        }
        for(int i=0; i<values.size();i++){
            if(flowers.size()!=0)newValues.set(i, newValues.get(i)/flowers.size());
            else newValues.set(i, newValues.get(i));
        }
        values = newValues;
    }

    public double entropy(){
        Map<String, Integer> counts = new HashMap<>();
        for (int i = 0; i < flowers.size(); i++) {
            Flower tmp = flowers.get(i);
            if (counts.containsKey(tmp.name)){
                int val = counts.get(tmp.name) + 1;
                counts.put(tmp.name, 1);
            }else {
                counts.put(tmp.name, 1);
            }
        }
        double entropy = 0;
        for (Map.Entry<String, Integer> entry: counts.entrySet()) {
            double howoften = (double) entry.getValue() / flowers.size();
            entropy -= howoften * (Math.log(howoften)/Math.log(2));
        }
        return entropy;
    }
}
