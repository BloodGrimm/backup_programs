/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad2;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import zad1.InputConverter;

@FunctionalInterface
interface ThrowingFunction<T, R> extends Function <T,R> {
    @Override
    default R apply(T t) {
        try {
            return applyWithException(t);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    R applyWithException(T t) throws Exception;
}

public class Main {
    public static void main(String[] args) throws IOException {
        ThrowingFunction<String,List<String>> flines = data -> {
            BufferedReader b1 = new BufferedReader(new FileReader(data));
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = b1.readLine()) != null){
                lines.add(line);
            }
            return lines;
        };
        Function<List<String>, String> join = data ->{
            String tmp = "";
            for (int i = 0; i < data.size(); i++) {
                tmp += data.get(i);
            }
            return tmp;
        };
        Function<String, List<Integer>> collectInts = data ->{
            List<Integer> numbers = new ArrayList<>();
            Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
            Matcher matcher = pattern.matcher(data);

            while (matcher.find()) {
                String numberStr = matcher.group();
                try {
                    int number = Integer.parseInt(numberStr);
                    numbers.add(number);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            return numbers;
        };

        Function<List<Integer>, Integer> sum = data ->{
            int tmp = 0;
            for (int i = 0; i < data.size(); i++) {
                tmp += data.get(i);
            }
            return tmp;
        };

        String fname = System.getProperty("user.home") + "/LamComFile.txt";
        InputConverter<String> fileConv = new InputConverter<>(fname);
        List<String> lines = fileConv.convertBy(flines);
        String text = fileConv.convertBy(flines, join);
        List<Integer> ints = fileConv.convertBy(flines, join, collectInts);
        Integer sumints = fileConv.convertBy(flines, join, collectInts, sum);

        System.out.println(lines);
        System.out.println(text);
        System.out.println(ints);
        System.out.println(sumints);

        List<String> arglist = Arrays.asList(args);
        InputConverter<List<String>> slistConv = new InputConverter<>(arglist);
        sumints = slistConv.convertBy(join, collectInts, sum);
        System.out.println(sumints);

        // Zadania badawcze:
        // Operacja flines zawiera odczyt pliku, zatem może powstac wyjątek IOException
        // Wymagane jest, aby tę operację zdefiniowac jako lambda-wyrażenie
        // Ale z lambda wyrażeń nie możemy przekazywac obsługi wyjatków do otaczającego bloku
        // I wobec tego musimy pisać w definicji flines try { } catch { }
        // Jak spowodować, aby nie było to konieczne i w przypadku powstania wyjątku IOException
        // zadziałała klauzula throws metody main
    }
}
