package zad3;

import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Maybe<T> {

    T maybe;

    private Maybe(T maybe) {
        if (maybe != null) {
            this.maybe = maybe;
        }else {
            this.maybe = (T) "";
        }
    }

    boolean isPresent(){
        if(maybe != ""){
            return true;
        }else {
            return false;
        }
    }


    public static <R>Maybe<R> of(R r) {
        return new Maybe<>(r);
    }

    @Override
    public String toString() {
        if (maybe != null) {
            return "Maybe has value " + maybe;
        }else
            return "Maybe is empty";
    }

    public void ifPresent(Consumer<T> consumer) {
        if(this.isPresent()){
            consumer.accept(maybe);
        }
    }

    public <R> Maybe <R> map(Function<T,R> function) {
        if (maybe != ""){
            return new Maybe<>(function.apply(maybe));
        }else {
            return (Maybe<R>) new Maybe<>("");
        }
    }

    public T get() {
        if (maybe != ""){
            return maybe;
        }else {
            throw new NoSuchElementException("maybe is empty");
        }
    }
    public T orElse(T defVal) {
        if (maybe != ""){
            return maybe;
        }else {
            return defVal;
        }
    }

    public Maybe<T> filter(Predicate<? super  T> predicate) {
        if(predicate.test(maybe) || maybe == ""){
            return this;
        }else {
            return (Maybe<T>) new Maybe<>("");
        }
    }


}
