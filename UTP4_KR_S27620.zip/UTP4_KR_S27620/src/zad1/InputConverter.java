package zad1;

import java.util.function.Function;

public class InputConverter <T> {

    T dane;

    public InputConverter(T t) {
        this.dane = t;
    }

    public <R> R convertBy(Function<?,?> ... funkcje){
        Function <T,R> f1 = (Function<T, R>) funkcje[0];
        for (int i = 1; i < funkcje.length; i++) {
            f1 = f1.andThen((Function<? super R, ? extends R>) funkcje[i]);
        }
        return f1.apply(dane);
    }
}
