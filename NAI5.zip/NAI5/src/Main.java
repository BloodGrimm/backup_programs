import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static List<Flower> training = new ArrayList<>();
    public static List<Flower> test = new ArrayList<>();

    public static void main(String[] args) {
        loadData(training);
        loadData2(test);
        NaiwnyBayes naiwnyBayes = new NaiwnyBayes(training, test);
        wlasnyKwiat(naiwnyBayes);
    }

    public static void loadData(List<Flower> training){
        try {
            Scanner scanner = new Scanner(new File("src/iris_training.txt"));
            while (scanner.hasNext()){
                Flower tmp = new Flower(scanner.nextLine());
                training.add(tmp);
            }
        }catch (Exception e){
            System.out.println("Problem z wczytaniem danych.");
        }
    }
    public static void loadData2(List<Flower> training){
        try {
            Scanner scanner = new Scanner(new File("src/iris_test.txt"));
            while (scanner.hasNext()){
                Flower tmp = new Flower(scanner.nextLine());
                training.add(tmp);
            }
        }catch (Exception e){
            System.out.println("Problem z wczytaniem danych.");
        }
    }

    public static void wlasnyKwiat(NaiwnyBayes naiwnyBayes){
        Scanner user = new Scanner(System.in);
        while (true){
            System.out.println("Podaj parametry wyszukiwanego kwiatu.");
            List<Double> a1 = new ArrayList<>();
            int size = test.get(0).atributes.size();
            for (int i = 0; i < size; i++) {
                System.out.println("Podaj parametr " + (i+1) + " z " + size);
                double variable = user.nextDouble();
                a1.add(variable);
            }
            Flower flower = new Flower(a1);
            System.out.println("Finalnie: " + naiwnyBayes.przyporzadkuj(flower));
        }
    }
}
