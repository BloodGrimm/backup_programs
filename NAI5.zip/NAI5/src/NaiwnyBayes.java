import java.util.*;

public class NaiwnyBayes {

    public List<Flower> training;
    public List<Flower> test;

    int correct = 0;
    String[] names = {"Iris-setosa", "Iris-versicolor", "Iris-virginica"};


    List<Set<Double>> uvpa = new ArrayList<>();


    public NaiwnyBayes(List<Flower> training, List<Flower> test) {
        this.training = training;
        this.test = test;
        znajdzNiepowtarzalne();
        wyniki();
    }

    public void znajdzNiepowtarzalne() {
        int numAttributes = training.get(0).atributes.size();

        for (int i = 0; i < numAttributes; i++) {
            uvpa.add(new HashSet<>());
        }

        for (Flower flower : training) {
            for (int i = 0; i < numAttributes; i++) {
                uvpa.get(i).add(flower.atributes.get(i));
            }
        }
    }


    public String przyporzadkuj(Flower flower) {
        String predname = "";
        double maxPrawd = -1;

        for (String name : names) {
            double prawd = 1.0;
            double prawdbez = 1.0;

            for (int i = 0; i < flower.atributes.size(); i++) {
                double attribute = flower.atributes.get(i);
                int ileatt = 0;
                int classCount = 0;

                for (Flower trainFlower : training) {
                    if (trainFlower.name.equals(name)) {
                        classCount++;
                        if (trainFlower.atributes.get(i).equals(attribute)) {
                            ileatt++;
                        }
                    }
                }
                prawd *= (ileatt + 1.0) / (classCount + uvpa.get(i).size());
                prawdbez *= (double) ileatt / classCount;
            }

            prawd *= (classCount(training, name) + 1.0) / (training.size() + names.length);

            System.out.println("Bez wygladzania: " + name + ": " + prawdbez);
            System.out.println("Z wygladzaniem " + name + ": " + prawd);

            if (prawd > maxPrawd) {
                maxPrawd = prawd;
                predname = name;
            }
        }
        return predname;
    }


    private int classCount(List<Flower> flowers, String name) {
        int count = 0;
        for (Flower flower : flowers) {
            if (flower.name.equals(name)) {
                count++;
            }
        }
        return count;
    }


    public void wyniki(){
        double[][] macierz = new double[names.length][names.length];
        for (int i = 0; i < test.size(); i++) {
            String wyl = przyporzadkuj(test.get(i));
            String dan = test.get(i).name;
            if (dan.equals("Iris-setosa") && wyl.equals("Iris-setosa")){
                macierz[0][0] += 1;
            }
            if (dan.equals("Iris-setosa") && wyl.equals("Iris-versicolor")){
                macierz[0][1] += 1;
            }
            if (dan.equals("Iris-setosa") && wyl.equals("Iris-virginica")){
                macierz[0][2] += 1;
            }
            if (dan.equals("Iris-versicolor") && wyl.equals("Iris-setosa")){
                macierz[1][0] += 1;
            }
            if (dan.equals("Iris-versicolor") && wyl.equals("Iris-versicolor")){
                macierz[1][1] += 1;
            }
            if (dan.equals("Iris-versicolor") && wyl.equals("Iris-virginica")){
                macierz[1][2] += 1;
            }
            if (dan.equals("Iris-virginica") && wyl.equals("Iris-setosa")){
                macierz[2][0] += 1;
            }
            if (dan.equals("Iris-virginica") && wyl.equals("Iris-versicolor")){
                macierz[2][1] += 1;
            }
            if (dan.equals("Iris-virginica") && wyl.equals("Iris-virginica")){
                macierz[2][2] += 1;
            }
            if (wyl.equals(dan)){
                correct += 1;
            }
        }
        System.out.println("Prawdopodobienstwo testow to: " + (double)correct/test.size() + "%.");
        System.out.println("Macierz omyłek: ");
        for (int i = 0; i < macierz.length; i++) {
            System.out.print(names[i] + ": ");
            for (int j = 0; j < macierz[i].length; j++) {
                System.out.print(macierz[i][j] + " ");
            }
            System.out.println();
        }
        List<Double> prec = precyzja(macierz);
        List<Double> pel = pelnosc(macierz);
        fmiara(prec, pel);

    }
    public List<Double> precyzja(double[][] macierz){
        List<Double> wynik = new ArrayList<>();
        System.out.println("Precyzja: ");
        wynik.add((macierz[0][0]/(macierz[0][0] + macierz[1][0] + macierz[2][0])));
        wynik.add((macierz[1][1]/(macierz[0][1] + macierz[1][1] + macierz[2][1])));
        wynik.add((macierz[2][2]/(macierz[0][2] + macierz[1][2] + macierz[2][2])));
        for (int i = 0; i < wynik.size(); i++) {
            System.out.println("Precyzja: " + names[i] + ": " + wynik.get(i));
        }
        return wynik;
    }
    public List<Double> pelnosc(double[][] macierz){
        List<Double> wynik = new ArrayList<>();
        System.out.println("Pełność: ");
        wynik.add((macierz[0][0]/(macierz[0][0] + macierz[0][1] + macierz[0][2])));
        wynik.add((macierz[1][1]/(macierz[1][0] + macierz[1][1] + macierz[1][2])));
        wynik.add((macierz[2][2]/(macierz[2][0] + macierz[2][1] + macierz[2][2])));
        for (int i = 0; i < wynik.size(); i++) {
            System.out.println("Pełność: " + names[i] + ": " + wynik.get(i));
        }
        return wynik;
    }
    public void fmiara(List<Double> prec, List<Double> pel){
        for (int i = 0; i < names.length; i++) {
            double wynik = (2* prec.get(i) * pel.get(i))/(prec.get(i) + pel.get(i));
            System.out.println("F-miara :" + names[i] + ": " + wynik);
        }
    }
}