package zad1;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CountiresTableModel extends AbstractTableModel{

    Object[][] dane;

    String [] nazwy;
    public CountiresTableModel(String [] nazwy, Object[][] dane) {
        this.dane = dane;
        this.nazwy = nazwy;
        for (int i = 0; i < getRowCount(); i++) {
            dane[i][4] = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(Calendar.getInstance().getTime());
        }
    }


    @Override
    public int getRowCount() {
        return dane.length;
    }

    @Override
    public int getColumnCount() {
        return nazwy.length;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(columnIndex == 2 || columnIndex == 4) {
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return dane[rowIndex][columnIndex];
    }

    @Override
    public String getColumnName(int column) {
        return nazwy[column];
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        String tmp = aValue.toString();
        for (int i = 0; i < tmp.length(); i++) {
            if(tmp.charAt(i) < 48 || tmp.charAt(i) > 57){
                JOptionPane.showMessageDialog(null, "Not a number");
                return;
            }
        }
            if (columnIndex == 2) {
                dane[rowIndex][4] = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(Calendar.getInstance().getTime());
            }
            dane[rowIndex][columnIndex] = aValue;
    }


}
