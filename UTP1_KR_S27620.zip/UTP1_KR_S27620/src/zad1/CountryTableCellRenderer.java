package zad1;

import javax.imageio.stream.ImageInputStream;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageProducer;

public class CountryTableCellRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        setIcon(null);
        Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (column == 2 && Integer.parseInt(value.toString()) >20000000){
            component.setForeground(Color.RED);
        }else {
            component.setForeground(Color.BLACK);
        }
        if (column == 3){
            setIcon(new ImageIcon(value.toString()));
        }
        return component;
    }
}
