package zad1;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CountryTable{

    String path;

    String [] nazwy;
    Object [][] dane;

    public CountryTable(String path) {
        super();
        this.path = path;
    }

    public JTable create() throws FileNotFoundException {
        JTable jTable = null;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
            String tmp = bufferedReader.readLine();
            nazwy = tmp.split("\t");
            dane = new Object[(int)countLines(path)-1][nazwy.length+2];
            long counter = 1;
            while (counter < countLines(path)){
                String tmp2 = bufferedReader.readLine();
                String [] linia = tmp2.split("\t");
                dane[(int)(counter)-1] = linia;
                counter+=1;
            }
            jTable = new JTable(new CountiresTableModel(nazwy, dane));
            jTable.setDefaultRenderer(Object.class, new CountryTableCellRenderer());
        }catch (IOException ioException){

        }
        return jTable;
    }

    public long countLines(String path){
        Path path1 = Paths.get(path);
        long lines = 0;
        try{
            lines = Files.lines(path1).count();
        }catch (IOException ioException){

        }
        return lines;
    }

}
