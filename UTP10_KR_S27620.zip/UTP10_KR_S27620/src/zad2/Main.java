/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad2;


import zad1.ThreadA;
import zad1.ThreadB;
import zad1.Towar;

import java.util.Stack;

public class Main {

  public static void main(String[] args) {
    Stack<Towar> q1 = new Stack<>();
    zad1.ThreadB thB = new ThreadB(q1);
    zad1.ThreadA thA = new ThreadA(q1, thB);
    thA.start();
    thB.start();
  }
}
