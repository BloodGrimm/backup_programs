package zad2;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;

public class ThreadA extends Thread{
    Stack<Towar> q1;

    ThreadB b;

    Scanner s1;
    public ThreadA(Stack <Towar> q1, ThreadB b){
        this.b = b;
        this.q1 = q1;
        try {
            s1 = new Scanner(new File("../Towary.txt"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        int count = 0;
        while (s1.hasNext()) {
            count+=1;
            q1.add(new Towar(s1.nextLine()));
            if(count%200 == 0){
                synchronized (b){
                    b.notify();
                }
                System.out.println("Wczytano " + count + " elementow");
            }
        }
        b.zakonczylA = true;
        try {
            synchronized (this) {
                wait(500);
            }
            synchronized (b){
                b.notify();
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
