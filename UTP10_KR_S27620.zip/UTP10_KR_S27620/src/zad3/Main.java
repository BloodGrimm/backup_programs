/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad3;


import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {

  public static void main(String[] args) {
    BlockingQueue<Towar> bq1 = new LinkedBlockingQueue<>();
    ThreadB thB = new ThreadB(bq1);
    ThreadA thA = new ThreadA(bq1, thB);
    thA.start();
    thB.start();
  }
}