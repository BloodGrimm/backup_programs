package zad3;

public class Towar {

    int id;

    double waga;
    public Towar(String line) {
        String[] data = line.split(" ");
        this.id = Integer.parseInt(data[0]);
        this.waga = Double.parseDouble(data[1]);
    }
}
