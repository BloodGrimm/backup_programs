package zad3;

import java.util.concurrent.BlockingQueue;

public class ThreadB extends Thread{

    BlockingQueue<Towar> q2;
    public boolean zakonczylA = false;

    public ThreadB(BlockingQueue<Towar> q2) {
        this.q2 = q2;
    }

    @Override
    public void run() {
        int count = 0;
        double waga = 0;
        while (!(zakonczylA) || !(q2.isEmpty())){
                count+=1;
            try {
                waga += q2.take().waga;
            } catch (InterruptedException e) {

            }
            if(count%100 == 0) {
                    System.out.println("Policzono " + count + " elementow");
                }
        }
        System.out.println(waga);
    }

}
