/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.util.Stack;

public class Main {

  public static void main(String[] args) {
    Stack<Towar> q1 = new Stack<>();
    ThreadB thB = new ThreadB(q1);
    ThreadA thA = new ThreadA(q1, thB);
    thA.start();
    thB.start();
  }
}
