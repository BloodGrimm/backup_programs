package zad1;

import java.util.Stack;

public class ThreadB extends Thread{

    Stack<Towar> q2;
    public boolean zakonczylA = false;

    public ThreadB(Stack<Towar> q2) {
        this.q2 = q2;
    }

    @Override
    public void run() {
        int count = 0;
        double waga = 0;
        while (!(zakonczylA) || !(q2.isEmpty())){
            if(q2.isEmpty()){
                synchronized (this){
                    try {
                        if (!zakonczylA) {
                            wait();
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                };
            }
            else {
                count+=1;
                waga += q2.pop().waga;
                if(count%100 == 0){
                    System.out.println("Policzono " + count + " elementow");
                }
            }
        }
        System.out.println(waga);
    }


}
