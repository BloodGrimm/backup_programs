import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {

    public static List<Flower> training = new ArrayList<>();
    public static List<Flower> test = new ArrayList<>();


    public static void main(String[] args) {
        File file1 = new File("src/iris_training.txt");
        Scanner sccount = new Scanner(System.in);
        System.out.print("Podaj ile cykli: ");
        int count = sccount.nextInt();
        load_data(file1, training);
        Perceptron perceptron = new Perceptron(training, count);
        perceptron.learn();
        File file2 = new File("src/iris_test.txt");
        load_data(file2, test);
        perceptron.check(test);
        userFlower(perceptron);
    }

    public static void userFlower(Perceptron perceptron){
        Scanner user = new Scanner(System.in);
        while (true){
            System.out.println("Podaj parametry wyszukiwanego kwiatu.");
            List<Double> a1 = new ArrayList<>();
            int size = test.get(0).atributes.size();
            for (int i = 0; i < size; i++) {
                System.out.println("Podaj parametr " + (i+1) + " z " + size);
                double variable = user.nextDouble();
                a1.add(variable);
            }
            Flower flower = new Flower(a1);
            perceptron.check(flower);
        }
    }
    public static void load_data(File file, List<Flower> data) {
        try {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                data.add(new Flower(sc.nextLine()));
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}