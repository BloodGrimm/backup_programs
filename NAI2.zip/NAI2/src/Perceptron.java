import java.util.ArrayList;
import java.util.List;

public class Perceptron {

    List<Flower> training;
    List<Double> weights = new ArrayList<>();
    int count;

    double prog = 1;

    double good = 0;
    double all = 0;

    public Perceptron(List<Flower> training, int count) {
        this.training = training;
        this.count = count;
        Flower tmp = training.get(0);
        for (int i = 0; i < tmp.atributes.size(); i++) {
            weights.add(1.0);
        }
    }

    public void learn(){
        double a = 0.5;
        for (int j = 0; j < count; j++) {
            for (int i = 0; i < training.size(); i++) {
                Flower tmp = training.get(i);
                String result = flowerResult(tmp);
                if (!result.equals(tmp.name.trim().equals("Iris-setosa")? "Iris-setosa" : "Not Iris-setosa")){
                    int d = 0;
                    int y = 0;
                    if (tmp.name.equals("Iris-setosa")){
                        d = 1;
                    }
                    if(result.equals("Iris-setosa")){
                        y = 1;
                    }
                    for (int k = 0; k < weights.size(); k++) {
                        double weight = weights.get(k) + (d - y)*a*tmp.atributes.get(k);
                        weights.set(k, weight);
                    }
                }
            }
        }
    }

    public void check(List<Flower> flowers){
        for (Flower a:flowers) {
            String result = flowerResult(a);
            System.out.print(a + " " + result);
            if(a.name.trim().equals("Iris-setosa") && result.equals("Iris-setosa")) {
                System.out.println(1);
                good += 1;
            } else if (!(a.name.equals("Iris-setosa")) && result.equals("Not Iris-setosa")) {
                good += 1;
                System.out.println(2);
            }
            all += 1;
        }
        System.out.println();
        double percentage = (good/all)*100;
        System.out.println("Dobrych jest: " + (int)(good) + "/" + (int)(all) + " czyli " + percentage + " procent.");
    }
    public void check(Flower flower){
        String result = flowerResult(flower);
        System.out.println("Kwiat to " + result + ".");
    }


    public String flowerResult(Flower flower){
        double sum = 0;
        for (int i = 0; i < flower.atributes.size(); i++) {
            sum += flower.atributes.get(i)*weights.get(i);
        }
        if(sum >= prog){
            return "Iris-setosa";
        }else {
            return "Not Iris-setosa";
        }
    }
}
