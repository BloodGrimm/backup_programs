/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

  public static Map<String, List<String>> map;
  public static void main(String[] args) {
    try {
      URL url = new URL("http://wiki.puzzlers.org/pub/wordlists/unixdict.txt");
      BufferedReader b1 = new BufferedReader(new InputStreamReader(url.openStream()));
      map = b1.lines().map(String::toLowerCase).collect(Collectors.groupingBy(Main::sortedTokens));
      int max = map.values().stream().map(List::size).max(Integer::compareTo).orElse(0);
      map.entrySet().stream().filter(a -> a.getValue().size() == max).sorted(Map.Entry.comparingByValue(Comparator.comparing(tmp -> tmp.get(0)))).forEach(tmp -> {
        tmp.getValue().stream().sorted().forEach(tmp2 -> System.out.print(tmp2 + " "));
        System.out.println();
      });
    }catch (IOException e){
      e.printStackTrace();
    }
  }

  public static String sortedTokens(String word){
    char[] tokens = new char[word.length()];
    for (int i = 0; i < word.length(); i++) {
      tokens[i] = word.charAt(i);
    }
    Arrays.sort(tokens);
    StringBuilder result = new StringBuilder();
    for (int i = 0; i < tokens.length; i++) {
      result.append(tokens[i]);
    }
    return result.toString();
  }
}
