/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.util.List;

public interface Mapper <T,Y> { // Uwaga: interfejs musi być sparametrtyzowany
    Y map(T t);
}  
