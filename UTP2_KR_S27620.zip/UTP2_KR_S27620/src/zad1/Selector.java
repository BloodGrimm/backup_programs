/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


public interface Selector<T> { // Uwaga: interfejs musi być sparametrtyzowany
    boolean select(T t);
}  
