/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;

public class ListCreator { // Uwaga: klasa musi być sparametrtyzowana

    List list;

    public ListCreator(List list) {
        this.list = list;
    }

    public static ListCreator collectFrom(List list){
        return new ListCreator(list);
    }

    public ListCreator when(Selector selector){
        List tmp = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            if (selector.select(list.get(i))){
                tmp.add(list.get(i));
            }
        }
        return new ListCreator(tmp);
    }

    public List mapEvery(Mapper mapper){
        List tmp = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            tmp.add(mapper.map(list.get(i)));
        }
        return tmp;
    }
}
