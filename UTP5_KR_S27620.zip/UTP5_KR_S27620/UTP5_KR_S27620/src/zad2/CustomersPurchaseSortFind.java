/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad2;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

public class CustomersPurchaseSortFind{

    ArrayList<Purchase> zakupy = new ArrayList<>();
    public void readFile(String fname) {
        try {
            System.out.println(fname);
            BufferedReader b1 = new BufferedReader(new FileReader(fname));
            String line;
            while ((line = b1.readLine()) != null){
                String [] tmp = line.split("[; ]");
                Purchase p1 = new Purchase(tmp);
                zakupy.add(p1);
            }
        }catch (IOException e){
            System.out.println("Problem with loading a file");
        }

    }

    public void showSortedBy(String tmp) {
        System.out.println(tmp);
        Comparator<Purchase> com1 = Purchase.compar(tmp);
        ArrayList<Purchase> tmp1 = new ArrayList<>(zakupy);
        tmp1.sort(com1);
        if (tmp.equals("Koszty")){
            for (int i = 0; i < tmp1.size(); i++) {
                System.out.println(tmp1.get(i).stringKoszt());
            }
        }else {
            for (int i = 0; i < tmp1.size(); i++) {
                System.out.println(tmp1.get(i).toString());
            }
        }
        System.out.println();
    }

    public void showPurchaseFor(String id) {
        System.out.println("Klient " + id);
        for (int i = 0; i < zakupy.size(); i++) {
            if(id.equals(zakupy.get(i).getId())){
                System.out.println(zakupy.get(i).toString());
            }
        }
        System.out.println();
    }
}
