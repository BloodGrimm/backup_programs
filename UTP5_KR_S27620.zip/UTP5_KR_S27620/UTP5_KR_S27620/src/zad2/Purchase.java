/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad2;


import java.text.Collator;
import java.util.Comparator;
import java.util.Locale;

public class Purchase{
    String id;
    String nazwisko;
    String imie;
    String towar;
    double cena;
    double ilosc;

    public Purchase(String[] data) {
        id = data[0];
        nazwisko = data[1];
        imie = data[2];
        towar = data[3];
        cena = Double.parseDouble(data[4]);
        ilosc = Double.parseDouble(data[5]);
    }

    public String getId() {
        return id;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public String getTowar() {
        return towar;
    }

    public double getCena() {
        return cena;
    }

    public double getIlosc() {
        return ilosc;
    }

    @Override
    public String toString() {
        return id +";" + nazwisko + " " + imie + ";" + towar + ";" + cena + ";" + ilosc;
    }

    public String stringKoszt(){
        return id +";" + nazwisko + " " + imie + ";" + towar + ";" + cena + ";" + ilosc + "(koszt: " + cena*ilosc + ")";
    }
    
    public static Comparator<Purchase> compar(String tmp){
        Collator collator = Collator.getInstance(new Locale("pl", "PL"));
        Comparator<Purchase> com1 = new Comparator<Purchase>() {
            @Override
            public int compare(Purchase p1, Purchase p2) {
                String id1 = p1.getId();
                String id2 = p2.getId();
                return collator.compare(id1,id2);
            }
        };
        if(tmp.equals("Nazwiska")){
            return new Comparator<Purchase>() {
                @Override
                public int compare(Purchase p1, Purchase p2) {
                    String nazw1 = p1.getNazwisko();
                    String nazw2 = p2.getNazwisko();
                    return collator.compare(nazw1, nazw2);
                }
            }.thenComparing(com1);
        } else if (tmp.equals("Koszty")) {
            return new Comparator<Purchase>() {
                @Override
                public int compare(Purchase p1, Purchase p2) {
                    double c1 = p1.getCena();
                    double c2 = p2.getCena();
                    double i1 = p1.getIlosc();
                    double i2 = p2.getIlosc();
                    if(c1*i1>c2*i2){
                        return -1;
                    } else if (c1*i1<c2*i2) {
                        return 1;
                    }else {
                        return 0;
                    }
                }
            }.thenComparing(com1);
        }
        return null;
    }
}
