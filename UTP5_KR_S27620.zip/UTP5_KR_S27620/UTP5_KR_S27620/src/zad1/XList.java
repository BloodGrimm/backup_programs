package zad1;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class XList <T> extends ArrayList<T> {

    public XList(T ... tmp) {
        for (int i = 0; i < tmp.length; i++) {
            this.add(tmp[i]);
        }
    }

    public XList(Collection<T> tmp) {
        this.addAll(tmp);
    }

    public static <T>XList<T> of(T ... tmp) {
        return new XList<>(tmp);
    }

    public static <T>XList<T> of(Collection<T> tmp) {
        return new XList<>(tmp);
    }

    public static XList charsOf(String alaMaKota) {
        String tmp = alaMaKota;
        return new XList(tmp.split(""));
    }

    public static <T>XList tokensOf(String alaMaKota, T ... splitter) {
        String tmp = alaMaKota;
        if(splitter.length > 0){
            String split1 = "[";
            for (int i = 0; i < splitter.length; i++) {
                split1 += splitter[i];
            }
            split1 += "]";
            return new XList(tmp.split(split1));
        }else {
            return new XList(tmp.split("\\s+"));
        }
    }

    public XList<T> union(Collection<T> collection) {
        XList<T> xList = new XList<>(this);
        xList.addAll(collection);
        return xList;
    }

    public XList<T> union(T ... tmp) {
        XList<T> xList = new XList<>(this);
        xList.addAll(Arrays.asList(tmp));
        return xList;
    }


    public XList<T> diff(Collection<T> collection) {
        XList<T> lista = new XList();
        for (int i = 0; i < this.size(); i++) {
            if(!(collection.contains(this.get(i)))){
                lista.add(this.get(i));
            }
        }
        return lista;
    }

    public XList unique() {
        XList<T> lista = new XList();
        for (int i = 0; i < this.size(); i++) {
            if(!(lista.contains(this.get(i)))){
                lista.add(this.get(i));
            }
        }
        return lista;
    }

    public XList<XList<T>> combine() {
        if(this.get(0) instanceof Collection || this.get(0).getClass().isArray()){
            return recurentionCom(this.size()-1);
        }else {
            XList<XList<T>> list = new XList<XList<T>>();
            for (int i = 0; i < this.size(); i++) {
                list.add(new XList<T>(this.get(i)));
            }
            return list;
        }
    }

private XList<XList<T>> recurentionCom(int list) {
        List<T> lista = (List<T>) this.get(list);
        XList<XList<T>> result = new XList<XList<T>>();
        if(list > 0){
            for (int i = 0; i < lista.size(); i++) {
                XList<XList<T>>part=recurentionCom(list-1);
                for (int j = 0; j < part.size(); j++) {
                    part.get(j).add(lista.get(i));
                    result.add(part.get(j));
                }
            }
        }else {
            for (int i = 0; i < lista.size(); i++) {
                result.add(new XList<T>(lista.get(i)));
            }
        }
        return result;
    }

    public <R> XList <R> collect(Function<T, R> function) {
        XList<R> result = new XList<>();
        for (int i = 0; i < this.size(); i++) {
            result.add(function.apply(this.get(i)));
        }
        return result;
    }
    public String join(String separator) {
        String tmp = "";
        for (int i = 0; i < this.size(); i++) {
            tmp+=this.get(i);
            if(!(i == this.size()-1)){
                tmp+=separator;
            }
        }
        return tmp;
    }

    public String join() {
        String tmp = "";
        for (int i = 0; i < this.size(); i++) {
            tmp+=this.get(i);
        }
        return tmp;
    }

    public void forEachWithIndex(BiConsumer<T,Integer> consumer) {
        for (int i = 0; i < this.size(); i++) {
            consumer.accept(this.get(i),i);
        }
    }
}