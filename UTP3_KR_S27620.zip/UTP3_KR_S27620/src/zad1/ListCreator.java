package zad1;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class ListCreator <T> {

    List <T> list;

    public ListCreator(List<T> list) {
        this.list = list;
    }

    static <T> ListCreator <T> collectFrom(List <T> list){
        return new ListCreator<>(list);
    }
    ListCreator <T> when(Predicate<T> test) {
        ArrayList<T> list2 = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (test.test(list.get(i))) {
                list2.add(list.get(i));
            }
        }
        return new ListCreator<>(list2);
    }

    <R> List <R> mapEvery(Function <T,R> wynik){
        ArrayList<R> list2 = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            list2.add(wynik.apply(list.get(i)));
        }
        return list2;
    }
}
