/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.io.File;
import java.io.IOException;
import java.util.*;

public class Anagrams {

    List<String> allwords = new ArrayList<>();

    public Anagrams(String file) {
        try {
            Scanner s1 = new Scanner(new File(file));
            while (s1.hasNext()){
                String word = s1.next();
                allwords.add(word);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    public String getAnagramsFor(String word) {
        char[] wordTokens = sortedTokens(word);
        List<String> anagrams = new ArrayList<>();
        String result = word + ": [";
        for (int i = 0; i < allwords.size(); i++) {
            if(Arrays.equals(wordTokens, sortedTokens(allwords.get(i)))){
                if(!(word.equals(allwords.get(i)))) {
                    anagrams.add(allwords.get(i));
                }
            }
        }
        for (int i = 0; i < anagrams.size(); i++) {
            result += anagrams.get(i);
            if (i < anagrams.size()-1){
                result += ", ";
            }
        }
        result += "]";
        return result;
    }

    public char[] sortedTokens(String word){
        char[] tokens = new char[word.length()];
        for (int i = 0; i < word.length(); i++) {
            tokens[i] = word.charAt(i);
        }
        Arrays.sort(tokens);
        return tokens;
    }

    public boolean isAnagram(String w1, String w2){
        if (Arrays.equals(sortedTokens(w1), sortedTokens(w2))){
            return true;
        }
        return false;
    }

    public List<String>[] getSortedByAnQty() {
        List<String> tmp = new ArrayList<>(allwords);
        List<List<String>> anagrams = new ArrayList<>();
        for (int i = 0; i < tmp.size();) {
            List<String> a1 = new ArrayList<>();
            String word = tmp.get(i);
            a1.add(word);
            tmp.remove(i);
            for (int j = 0; j < tmp.size(); j++) {
                if (isAnagram(word, tmp.get(j))){
                    a1.add(tmp.get(j));
                    tmp.remove(j);
                    j--;
                }
            }
            anagrams.add(a1);
        }
        int length = anagrams.size();
        List<String>[] result = new List[length];
        for (int i = 0; i < anagrams.size(); i++) {
            result[i] = anagrams.get(i);
        }
        Arrays.sort(result, new Comparator<List<String>>() {
            @Override
            public int compare(List<String> o1, List<String> o2) {
                if (o1.size() > o2.size()){
                    return -1;
                }if (o2.size() > o1.size()){
                    return 1;
                }else {
                    return 0;
                }
            }
        }.thenComparing(list -> list.get(0)));
        return result;
    }
}
