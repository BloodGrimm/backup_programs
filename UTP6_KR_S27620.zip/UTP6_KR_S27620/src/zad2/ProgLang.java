package zad2;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;

public class ProgLang {

    LinkedHashMap<String, Set<String>> map1 = new LinkedHashMap<>();
    LinkedHashMap<String, Set<String>> map2 = new LinkedHashMap<>();
    public ProgLang(String file) {
        try {
            Scanner s1 = new Scanner(new File(file));
            while (s1.hasNext()){
                String[] tmp = s1.nextLine().split("\t");
                map1.put(tmp[0], new LinkedHashSet<>(Arrays.asList(tmp).subList(1,tmp.length)));
            }
            List<String> pracownicy = new ArrayList<>();
            for (Map.Entry<String, Set<String>> iterator : map1.entrySet()) {
                Set<String> set = iterator.getValue();
                String[] prog1 = set.toArray(new String[set.size()]);
                for (int i = 0; i < prog1.length; i++) {
                    if (!(pracownicy.contains(prog1[i]))){
                        pracownicy.add(prog1[i]);
                    }
                }
            }
            for (int i = 0; i < pracownicy.size(); i++) {
                List<String> jezyki  = new ArrayList<>();
                for (Map.Entry<String, Set<String>> iterator : map1.entrySet()) {
                    if(iterator.getValue().contains(pracownicy.get(i))){
                        jezyki.add(iterator.getKey());
                    }
                }
                map2.put(pracownicy.get(i), new LinkedHashSet<>(jezyki));
            }

        }catch (IOException e){
            e.printStackTrace();
        }
    }


    public LinkedHashMap<String, Set<String>> getLangsMap() {
        return map1;
    }

    public LinkedHashMap<String, Set<String>> getProgsMap() {
        return map2;
    }

    public <T,R> LinkedHashMap<T,R> sorted(Map<T,R> map, Comparator<Map.Entry<T,R>> comparator){
        return map.entrySet().stream().sorted(comparator).collect(LinkedHashMap::new, (result, entry) -> result.put(entry.getKey(), entry.getValue()), Map::putAll);
    }

    public LinkedHashMap<String, Set<String>> getLangsMapSortedByNumOfProgs() {
        Comparator <Map.Entry<String, Set<String>>> com1 = ((Comparator<Map.Entry<String, Set<String>>>) (o1, o2) -> {
            if (o1.getValue().size() > o2.getValue().size()) {
                return -1;
            } else if (o2.getValue().size() > o1.getValue().size()) {
                return 1;
            } else {
                return 0;
            }
        }).thenComparing(Map.Entry::getKey);
        return sorted(map1, com1);
    }

    public LinkedHashMap<String, Set<String>> getProgsMapSortedByNumOfLangs() {
        Comparator <Map.Entry<String, Set<String>>> com1 = ((Comparator<Map.Entry<String, Set<String>>>) (o1, o2) -> {
            if (o1.getValue().size() > o2.getValue().size()) {
                return -1;
            } else if (o2.getValue().size() > o1.getValue().size()) {
                return 1;
            } else {
                return 0;
            }
        }).thenComparing(Map.Entry::getKey);
        return sorted(map2, com1);
    }

    public <T,R> LinkedHashMap<T,R> filtered(Map<T,R> map, Predicate<Map.Entry<T,R>> predicate){
        return map.entrySet().stream().filter(predicate).collect(LinkedHashMap::new, (result, entry) -> result.put(entry.getKey(), entry.getValue()), Map::putAll);
    }

    public LinkedHashMap<String, Set<String>> getProgsMapForNumOfLangsGreaterThan(int i) {
        Predicate <Map.Entry<String, Set<String>>> pred1 = new Predicate<Map.Entry<String, Set<String>>>() {
            @Override
            public boolean test(Map.Entry<String, Set<String>> stringSetEntry) {
                if(stringSetEntry.getValue().size() > i){
                    return true;
                }else {
                    return false;
                }
            }
        };
        return filtered(map2, pred1);
    }
}
