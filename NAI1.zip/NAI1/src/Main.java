import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.Math;

public class Main {
    public static List<Double> ranges = new ArrayList<>();
    public static double good = 0;
    public static double all = 0;
    public static int k = 0;



    public static void main(String[] args) {
        File file = new File("src/iris_training.txt");
        List<Flower> training = new ArrayList<>();
        load_training(file, training);
        range(training);
        file = new File("src/iris_test.txt");
        System.out.print("Podaj ilu sasiadow: ");
        Scanner ksc = new Scanner(System.in);
        k = ksc.nextInt();
        test_data(file, training);
        double procent = (good / all) * 100;
        int correct = (int)good;
        int everything = (int)all;
        System.out.println("Dobrych jest " + correct + "/" + everything + " czyli " + procent + "%.");
        userFlower(training);

    }
    public static void userFlower(List<Flower> training){
        Scanner user = new Scanner(System.in);
        while (true){
            System.out.println("Podaj parametry wyszukiwanego kwiatu.");
            List<Double> a1 = new ArrayList<>();
            for (int i = 0; i < ranges.size(); i++) {
                System.out.println("Podaj parametr " + (i+1) + " z " + ranges.size());
                double variable = user.nextInt();
                a1.add(variable);
            }
            Flower f1 = new Flower(a1);
            List<FlowerRanged> neighbours = new ArrayList<>();
            for (int i = 0; i < training.size(); i++) {
                neighbours.add(new FlowerRanged(training.get(i)));
                neighbours.get(i).setRange(calculate(f1, training.get(i)));
            }
            Collections.sort(neighbours);
            List<String> names = new ArrayList<>();
            for (int i = 0; i < k; i++) {
                names.add(neighbours.get(i).getName());
            }
            System.out.println("Nazwa kwiatu to: " + getName(names));
        }
    }
    public static void load_training(File file, List<Flower> training){
        try {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()){
                training.add(new Flower(sc.nextLine()));
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    public static void range(List<Flower> training){
        List<Double> mins = new ArrayList<>();
        List<Double> maxes = new ArrayList<>();
        for (int i = 0; i < training.get(0).getAtributes().size(); i++) {
            mins.add(training.get(0).getAtributes().get(i));
            maxes.add(training.get(0).getAtributes().get(i));

        }
        for (int i = 1; i < training.size(); i++) {
            Flower tmp = training.get(i);
            for (int j = 0; j < tmp.getAtributes().size(); j++) {
                if(tmp.getAtributes().get(j) < mins.get(j)){
                    mins.set(j, tmp.getAtributes().get(j));
                }
                if(tmp.getAtributes().get(j) > maxes.get(j)){
                    maxes.set(j, tmp.getAtributes().get(j));
                }
            }
        }
        for (int i = 0; i < mins.size(); i++) {
            ranges.add(maxes.get(i)-mins.get(i));
        }
        System.out.println();
    }
    public static void test_data(File file, List<Flower> training){
        try {
            Scanner sc1 = new Scanner(file);
            while (sc1.hasNext()){
                Flower f1 = new Flower(sc1.nextLine());
                compare(f1, training);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public static void compare(Flower flower, List<Flower> training){
        List<FlowerRanged> neighbours = new ArrayList<>();
        for (int i = 0; i < training.size(); i++) {
            neighbours.add(new FlowerRanged(training.get(i)));
            neighbours.get(i).setRange(calculate(flower, training.get(i)));
        }
        Collections.sort(neighbours);
        List<String> names = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            names.add(neighbours.get(i).getName());
            System.out.println(names.get(i) + " " + neighbours.get(i).getName());
        }
        all += 1;
        if (getName(names).trim().equals(flower.name.trim())){
            good += 1;
        }
    }
    public static double calculate(Flower newflower, Flower neighbour){
        List<Double> datanew = newflower.getAtributes();
        List<Double> datatrain = neighbour.getAtributes();
        double result = 0;
        for (int i = 0; i < datanew.size(); i++) {
            double tmp = (datanew.get(i)-datatrain.get(i))/(ranges.get(i));
            result+= Math.pow(tmp,2);
        }
        result = Math.sqrt(result);
        return  result;
    }

    public static String getName(List<String> names){
        LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
        int max = 0;
        String name = "";
        for (int i = 0; i < names.size(); i++) {
            if(counts.containsKey(names.get(i))){
                counts.put(names.get(i),counts.get(names.get(i))+1);
            }else{
                counts.put(names.get(i),1);
            }
        }
        for (Map.Entry<String, Integer> tmp: counts.entrySet()) {
            if(tmp.getValue() > max){
                max = tmp.getValue();
                name = tmp.getKey();
            }
        }
        return name;
    }
}