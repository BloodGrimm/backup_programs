import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FlowerRanged implements Comparable<FlowerRanged> {

    String name;
    List<Double> atributes = new ArrayList<>();

    double range = 0;
    public FlowerRanged(Flower flower) {
        this.name = flower.name;
        this.atributes = flower.getAtributes();
    }


    public void setRange(double range) {
        this.range = range;
    }


    public String getName() {
        return name;
    }

    @Override
    public int compareTo(FlowerRanged o) {
        return Double.compare(this.range,o.range);
    }
}
