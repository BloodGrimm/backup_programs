import java.util.ArrayList;
import java.util.List;

public class Flower {

    String name;
    List<Double> atributes = new ArrayList<>();

    public Flower(List<Double> atributes) {
        this.atributes = atributes;
    }

    public Flower(String line) {
        String [] tmp = line.split("\t");
        for (int i = 0; i < tmp.length; i++) {
            if(i == tmp.length-1){
                this.name = tmp[i];
            }else {
                atributes.add(Double.parseDouble(tmp[i].replace(",", ".")));
            }
        }
    }

    @Override
    public String toString() {
        String answer =  "Flower" + " name= '" + name + "' ";
        for (int i = 0; i < atributes.size(); i++) {
            answer += atributes.get(i);
            answer += ", ";
        }
        return answer;
    }

    public List<Double> getAtributes() {
        return atributes;
    }
}
