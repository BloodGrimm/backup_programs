import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ASD2 {
    public static String worst = "";
    public static void main(String[] args) {
        Drzewo korzen = new Drzewo();
        try {
            Scanner scanner = new Scanner(new File(args[0]));
            while (scanner.hasNext()) {
                korzen.dodajDrzewo(scanner.nextLine(), 2);
            }
            findWorstWord(korzen, "");
        }catch (IOException e){
            e.printStackTrace();
        }
        System.out.println(worst);
    }
    public static void findWorstWord(Drzewo drzewo, String word){
        if (drzewo.getLeft() == null && drzewo.getRight() == null){
            word = drzewo.getEtykieta() + word;
            if(word.compareTo(worst) > 0){
                worst = word;
            }
        }
        if(drzewo.getRight() != null){
            findWorstWord(drzewo.getRight(), drzewo.getEtykieta() + word);
        }
        if(drzewo.getLeft() != null){
            findWorstWord(drzewo.getLeft(), drzewo.getEtykieta() + word);
        }
    }

}

class Drzewo{
    char etykieta;

    Drzewo left;

    Drzewo right;


    public char getEtykieta() {
        return etykieta;
    }

    public void dodajDrzewo(String linia, int pozycja){
        if (pozycja > linia.length()-1){
            etykieta = linia.charAt(0);
        }else {
            if (linia.charAt(pozycja) == 'L'){
                if (left == null){
                    left = new Drzewo();
                }
                left.dodajDrzewo(linia, pozycja+1);
            }
            if (linia.charAt(pozycja) == 'R'){
                if (right == null){
                    right = new Drzewo();
                }
                right.dodajDrzewo(linia, pozycja+1);
            }
        }
    }

    public Drzewo getLeft() {
        return left;
    }

    public Drzewo getRight() {
        return right;
    }
}
