import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ASD3 {
        public static void main(String[] args) {
            try {
                Scanner scanner = new Scanner(new File(args[0]));
                int op = Integer.parseInt(scanner.nextLine());
                AVLTree avl = new AVLTree(op, scanner);
            }catch (IOException e){
                System.out.println("File not found");
            }
    }
}

class AVLTree{

    Node root;
    public AVLTree(int op, Scanner scan) {
        while (scan.hasNext()){
            int liczba = scan.nextInt();
            root = insert(root, liczba, null);
        }
        Node znacznik = ostatniLewo(root);
        for (int i = 0; i < op; i++) {
            if(znacznik.wartosc%2 == 0){
                System.out.println("dziala delete");
                root = delete(znacznik,nastepny(root,znacznik));
            }else {
                System.out.println("dziala add");
                root = add(root, znacznik.wartosc-1, znacznik);
            }
            for (int j = 0; j <= znacznik.wartosc; j++) {
                znacznik = nastepny(root, znacznik);
            }
            System.out.println(znacznik.wartosc);
        }
        System.out.println("bla");
    }

    int wysokosc(Node n){
        if (n == null){
            return 0;
        }
        return n.getWysokosc();
    }

    int getBalance(Node n){
        if(n == null){
            return 0;
        }
        return wysokosc(n.right) - wysokosc(n.left);
    }

    Node insert(Node node, int wartosc, Node nadrzedny){
        if(node == null){
            return new Node(wartosc, nadrzedny);
        }
        node.right = insert(node.right, wartosc, node);
        nowaWysokosc(node.right);
        nowaWysokosc(node);
        return zbalansuj(node);
    }

    Node add(Node node, int wartosc, Node znacznik){
        if(node == null){
            return new Node(wartosc, null);
        }
        if(znacznik.right == null){
            Node tmp = new Node(wartosc, znacznik);
            znacznik.right = tmp;
            tmp.nadrzedny = znacznik;
            nowaWysokosc(znacznik);
        }else {
            Node dodaj = znacznik.right;
            while (dodaj.left != null){
                dodaj = dodaj.left;
                nowaWysokosc(dodaj);
            }
            dodaj.left = new Node(wartosc, dodaj);
            dodaj.left.nadrzedny = dodaj;
            nowaWysokosc(znacznik);
        }

        return zbalansuj(node);
    }

    Node delete(Node tree, Node znacznik){
        if(tree == null){
            return null;
        }
        Node usun = nastepny(tree, znacznik);
        Node tmp;
        //brak dzieci
        if(usun.left == null && usun.right == null){
            if(usun.nadrzedny.right.equals(usun)){
                usun.nadrzedny.right = null;
            }else {
                usun.nadrzedny.left = null;
            }
            return balansujDrzewo(usun.nadrzedny);
        }
        //lewe dziecko
        else if (usun.right == null){
            tmp = usun.left;
            if(usun.nadrzedny.right != null && usun.nadrzedny.right.equals(usun)){
                usun.nadrzedny.right = tmp;
            }else {
                usun.nadrzedny.left = tmp;
            }
            tmp.nadrzedny = usun.nadrzedny;
            return balansujDrzewo(tmp);
        }
        //prawe drzwo
        else if (usun.left == null){
            tmp = usun.right;
            if(usun.nadrzedny.left != null && usun.nadrzedny.left.equals(usun)){
                usun.nadrzedny.left = tmp;
            }else {
                usun.nadrzedny.right = tmp;
            }
            tmp.nadrzedny = usun.nadrzedny;
            return balansujDrzewo(tmp);
        }
        else {
            //2 dzieci
            Node tmp2 = usun.right;
            Node nad;
            while (tmp2.left != null){
                tmp2 = tmp2.left;
            }
            nad = tmp2.nadrzedny;
            if(usun.nadrzedny.right.equals(usun)){
                usun.nadrzedny.right = tmp2;
            }else {
                usun.nadrzedny.left = tmp2;
            }
            tmp2.right = usun.right;
            tmp2.left = usun.left;
            tmp2.right.nadrzedny = nad;
            tmp2.left.nadrzedny = nad;
            return balansujDrzewo(nad);
        }
    }

    Node balansujDrzewo(Node tree){
        nowaWysokosc(tree);
        while (tree.nadrzedny != null){
            nowaWysokosc(tree);
            tree = zbalansuj(tree).nadrzedny;
        }
        nowaWysokosc(tree);
        return tree;
    }

    Node nastepny(Node tree, Node znacznik){
        Node usun;
        if(znacznik.right != null) {
            usun = znacznik.right;
            while (usun.left != null) {
                usun = usun.left;
            }
        }else{
            while (znacznik.nadrzedny != null && znacznik.equals(znacznik.nadrzedny.right)) {
                znacznik = znacznik.nadrzedny;
            }
            if(znacznik.nadrzedny == null){
                znacznik = ostatniLewo(znacznik);
            }
            return znacznik;
        }
        return usun;
    }

    Node ostatniLewo(Node tree){
        Node odp = tree;
        while (odp.left != null){
            odp = odp.left;
        }
        return odp;
    }

    void nowaWysokosc(Node node){
        node.wysokosc = maxWysokosc(node);
    }

    int maxWysokosc(Node node){
        if(node.right == null && node.left == null){
            return 0;
        }
        if(node.right == null && !(node.left == null)){
            return node.left.getWysokosc()+1;
        }
        if(node.left == null && !(node.right == null)){
            return node.right.getWysokosc()+1;
        }
        if (node.right.getWysokosc() > node.right.getWysokosc()){
            return node.right.getWysokosc()+1;
        }
        else return node.left.getWysokosc() + 1;
    }

    int Max(int a, int b){
        if (a > b){
            return a;
        }else {
            return b;
        }
    }

    Node prawaRotacja(Node root){
        Node a = root.left;
        Node tmp = a.right;

        a.right = root;
        root.left = tmp;

        a.nadrzedny = root.nadrzedny;
        root.nadrzedny = a;


        nowaWysokosc(root);
        nowaWysokosc(a);

        return a;
    }

    Node lewaRotacja(Node root){
        Node b = root.right;
        Node tmp = b.left;

        b.left = root;
        root.right = tmp;

        b.nadrzedny = root.nadrzedny;
        root.nadrzedny = b;

        nowaWysokosc(root);
        nowaWysokosc(b);

        return b;
    }

    Node zbalansuj(Node pier){
        int balans = getBalance(pier);

        if(balans <= -1){
            if(getBalance(pier.left) <=0){
                pier = prawaRotacja(pier);
            }else {
                pier.left = lewaRotacja(pier.left);
                pier = prawaRotacja(pier);
            }
        }

        if(balans >= 1){
            if(getBalance(pier.right) >= 0){
                pier = lewaRotacja(pier);
            }else {
                pier.right = prawaRotacja(pier.right);
                pier = lewaRotacja(pier);
            }
        }

        return pier;
    }
}

class Node {
    int wartosc;

    int wysokosc = 1;

    Node left;
    Node right;

    Node nadrzedny;

    public int getWartosc() {
        return wartosc;
    }

    public int getWysokosc() {
        return wysokosc;
    }

    public Node(int wartosc, Node nadrzedny) {
        this.wartosc = wartosc;
        this.nadrzedny = nadrzedny;
    }
}