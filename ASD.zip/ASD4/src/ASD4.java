import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ASD4 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(new File(args[0]));
            Heap heap = new Heap(scanner);
            Huffman huffman = new Huffman(heap);
        }catch (IOException e){
            System.out.println("Nie znaleziono pliku.");
        }
    }
}

class Heap {
    Scanner scan;


    Node [] heep;

    int size = 0;
    public Heap(Scanner scan) {
        heep = new Node[256];
        size = 0;
        while (scan.hasNextLine()){
            String line = scan.nextLine();
            String[] data = line.split(" ");
            char token = data[0].charAt(0);
            int count = Integer.parseInt(data[1]);
            addtoHeap(new Node(token, count));
        }
    }

    void addtoHeap(Node node){
        heep[size] = node;
        checkParent(size);
        size += 1;
    }

    void checkParent(int index){
        int indexParent = (index - 1) /2;
        while (index >= 1 && heep[index].count < heep[indexParent].count){
            Node tmp = heep[indexParent];
            heep[indexParent] = heep[index];
            heep[index] = tmp;
            index = indexParent;
            indexParent = (index - 1)/2;
        }
    }

    public Node takeMin(){
        Node min = heep[0];
        size -= 1;
        heep[0] = heep[size];
        heep[size] = null;
        checkChild(0);
        return min;
    }

    void checkChild(int index){
        int indxright = 2 * index + 2;
        int indxleft = 2 * index + 1;
        int tmp = index;
        if(indxleft < size && heep[indxleft].count < heep[tmp].count){
            tmp = indxleft;
        }
        if(indxright < size && heep[indxright].count < heep[tmp].count){
            tmp = indxright;
        }
        if(tmp != index){
            Node tmp2 = heep[index];
            heep[index] = heep[tmp];
            heep[tmp] = tmp2;
            checkChild(tmp);
        }
    }
}

class Huffman{

    Node huffmanTree;


    Heap heap;

    public Huffman(Heap heap) {
        this.heap = heap;
        if(heap.size == 1){
            System.out.println(heap.heep[0].letter + " 0");
        }else {
            makeHuffmanTree();
            makeCodes(huffmanTree, "");
        }
    }

    public void makeHuffmanTree(){
        while (heap.size > 1){
            Node leftchild = heap.takeMin();
            Node rightchild = heap.takeMin();
            Node combine = new Node(' ', leftchild.count + rightchild.count);
            combine.right = rightchild;
            combine.left = leftchild;
            heap.addtoHeap(combine);
        }
        huffmanTree = heap.takeMin();
    }

    public void makeCodes(Node node, String code){
        if(node != null){
            if(node.left == null && node.right == null){
                System.out.println(node.letter + " " + code);
            }
            String tmp = code + "0";
            makeCodes(node.left, tmp);
            tmp = code + "1";
            makeCodes(node.right, tmp);
        }
    }

}

class Node{

    char letter;
    int count;
    Node left;
    Node right;

    public Node(char token, int count) {
        this.letter = token;
        this.count = count;
    }
}