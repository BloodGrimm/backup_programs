import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ASD3 {
    public static void main(String[] args) {
        try {
            Scanner scan = new Scanner(new File(args[0]));
            AVLTree avl = new AVLTree(scan);
        }catch (IOException e){
            System.out.println("Plik nie istnieje");
        }
    }
}

class AVLTree {

    Node root;
    Node znacznik;

    int op;
    int liczba_nodeow;
    int index;

    public AVLTree(Scanner scan) {
        this.op = scan.nextInt();
        scan.nextLine();
        while (scan.hasNext()){
            int liczba = scan.nextInt();
            if (root == null){
                root = new Node(liczba,null);
            }
            else {
                root = insert(root, liczba);
            }
        }
        while (op > 0){
            if(root != null){
                this.liczba_nodeow = root.rozmiar;
                index = index % this.liczba_nodeow;
                this.znacznik = this.znajdzElement(root, index);
                if(this.znacznik.wartosc % 2 == 0){
                    int delete;
                    if(index + 1 == this.liczba_nodeow){
                        delete = 0;
                        index = index - 1;
                    }else {
                        delete = index + 1;
                    }
                    Node deleteNode = this.znajdzElement(root, delete);
                    index += deleteNode.wartosc;
                    root = this.delete(deleteNode);
                }else {
                    root = this.add(this.znacznik, this.znacznik.wartosc-1);
                    index += this.znacznik.wartosc;
                }
            }
            op --;
        }
        if(root != null) {
            this.liczba_nodeow = root.rozmiar;
        }
        index = index % this.liczba_nodeow;
        scan.close();
        wyswietlDrzewo(root, liczba_nodeow, index);
    }

    Node add(Node root, int wartosc) {
        Node prawy = root.right;
        root.right = new Node(wartosc, root);
        root.right.nadrzedny = root;
        if(prawy != null){
            prawy.nadrzedny = root.right;
            root.right.right = prawy;
        }
        Node tmp = root.right;
        tmp.aktualizujWszystkie();
        tmp = zbalansuj(tmp);
        while (tmp.nadrzedny != null) {
            tmp = tmp.nadrzedny;
            tmp.aktualizujWszystkie();
            tmp = zbalansuj(tmp);
        }
        return tmp;
    }

    Node delete(Node usuwany) {
        Node tmp = usuwany;
        if(usuwany.left == null && usuwany.right == null){
                if (tmp.nadrzedny != null && tmp.nadrzedny.left == tmp) {
                    tmp.nadrzedny.left = null;
                } else if (tmp.nadrzedny != null && tmp.nadrzedny.right == tmp) {
                    tmp.nadrzedny.right = null;
                }
                else {
                    return null;
                }
        }
        else  {
            if (usuwany.right != null) {
                tmp = usuwany.right;
                while (tmp.left != null) {
                    tmp = tmp.left;
                }
                if (tmp.right != null) {
                    tmp.right.nadrzedny = tmp.nadrzedny;
                    if (tmp.nadrzedny.left == tmp) {
                        tmp.nadrzedny.left = tmp.right;
                    } else if (tmp.nadrzedny.right == tmp) {
                        tmp.nadrzedny.right = tmp.right;
                    }
                } else {
                    if (tmp.nadrzedny.left == tmp) {
                        tmp.nadrzedny.left = null;
                    } else if (tmp.nadrzedny.right == tmp) {
                        tmp.nadrzedny.right = null;
                    }
                }
            } else {
                tmp = usuwany.left;
                if(tmp.left != null){
                    tmp.left.nadrzedny = usuwany;
                }
                if(tmp.right != null) {
                    tmp.right.nadrzedny = usuwany;
                }
                usuwany.left = tmp.left;
                usuwany.right = tmp.right;
            }
        }
        usuwany.wartosc = tmp.wartosc;
        while (tmp.nadrzedny != null) {
            tmp = tmp.nadrzedny;
            tmp.aktualizujWszystkie();
            tmp = zbalansuj(tmp);
        }
        return tmp;
    }


    void wyswietlDrzewo(Node root, int size, int p) {
        if (root == null) {
            System.out.println("Puste drzwo");
        } else {
            Node index;
            for (int i = p; i < size; i++) {
                index = znajdzElement(root, i);
                System.out.print(index.wartosc + " ");
            }
            for (int i = 0; i < p; i++) {
                index = znajdzElement(root, i);
                System.out.print(index.wartosc + " ");
            }
        }
    }

    public Node znajdzElement(Node node, int szukany) {
        if (node == null)return null;
        int lewaWielkosc=0;
        if (node.left != null)lewaWielkosc = node.left.rozmiar;
        if (lewaWielkosc > szukany) {
            return znajdzElement(node.left, szukany);
        } else if (lewaWielkosc < szukany) {
            return znajdzElement(node.right, szukany - lewaWielkosc - 1);
        } else {
            return node;
        }
    }

    Node insert(Node root, int wartosc){
        while (root.right != null){
            root = root.right;
        }
        root.right = new Node(wartosc, root);
        root = root.right;
        while (root.nadrzedny!=null){
            root = root.nadrzedny;
            root.aktualizujWszystkie();
            root = zbalansuj(root);
        }
        return root;
    }

    Node prawaRotacja(Node root){
        Node lewe = root.left;

        root.left = lewe.right;
        if (lewe.right != null){
            lewe.right.nadrzedny = root;
        }

        lewe.right = root;
        lewe.nadrzedny = root.nadrzedny;

        if(root.nadrzedny != null) {
            if (root.nadrzedny.left == root) {
                root.nadrzedny.left = lewe;
            } else if (root.nadrzedny.right == root) {
                root.nadrzedny.right = lewe;
            }
        }

        root.nadrzedny = lewe;
        root.aktualizujWszystkie();
        lewe.aktualizujWszystkie();

        return lewe;
    }

    Node lewaRotacja(Node root){
        Node prawe = root.right;

        root.right = prawe.left;
        if (prawe.left != null){
            prawe.left.nadrzedny = root;
        }

        prawe.left = root;
        prawe.nadrzedny = root.nadrzedny;

        if(root.nadrzedny != null) {
            if (root.nadrzedny.left == root) {
                root.nadrzedny.left = prawe;
            } else if (root.nadrzedny.right == root) {
                root.nadrzedny.right = prawe;
            }
        }

        root.nadrzedny = prawe;
        root.aktualizujWszystkie();
        prawe.aktualizujWszystkie();

        return prawe;
    }

    Node zbalansuj(Node pier){
        int balans = pier.getBalance();

        if(balans < -1){
            if (pier.left.getBalance() > 0) {
                pier.left = lewaRotacja(pier.left);
            }
            pier = prawaRotacja(pier);
        }

        if(balans > 1){
            if (pier.right.getBalance() < 0) {
                pier.right = prawaRotacja(pier.right);
            }
            pier = lewaRotacja(pier);
        }

        return pier;
    }
}

class Node {
    int wartosc;

    int wysokosc = 0;

    int rozmiar = 1;

    Node left;
    Node right;

    Node nadrzedny;


    public int getWysokosc() {
        return wysokosc;
    }

    public Node(int wartosc, Node nadrzedny) {
        this.wartosc = wartosc;
        this.nadrzedny = nadrzedny;
    }

    void nowaWysokosc(){
        this.wysokosc = max(wysokosc(this.left), wysokosc(this.right)) + 1;
    }

    int max(int a, int b){
        if (a > b){
            return a;
        }else {
            return b;
        }
    }

    int getBalance(){
        return wysokosc(this.right) - wysokosc(this.left);
    }

    int wysokosc(Node n){
        if (n == null){
            return -1;
        }
        return n.getWysokosc();
    }

    public void nowyRozmiar(){
        rozmiar = 1;
        if(left != null){
            rozmiar += left.rozmiar;
        }
        if(right != null){
            rozmiar += right.rozmiar;
        }
    }

    void aktualizujWszystkie(){
        this.nowyRozmiar();
        this.nowaWysokosc();
    }
}