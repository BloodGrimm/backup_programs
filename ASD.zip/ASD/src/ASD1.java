import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ASD1 {
    public static void main(String[] args) {
        try {
            File file = new File(args[0]);
            Scanner input = new Scanner(file);
            int maxlen = 1;
            int sum = Integer.parseInt(input.next());
            int sumros = sum;
            int summal = sum;
            int lenmal = 1;
            int lenros = 1;
            int liczba1 = sum;
            while (input.hasNext()){
                int liczba2 = Integer.parseInt(input.next());
                if (liczba2 > liczba1){
                    lenmal = 1;
                    lenros+=1;
                    summal = liczba2;
                    sumros+=liczba2;
                    if(lenros > maxlen){
                        maxlen = lenros;
                        sum = sumros;
                    }
                }else if (liczba1 > liczba2){
                    lenros = 1;
                    lenmal+=1;
                    sumros = liczba2;
                    summal+=liczba2;
                    if(lenmal > maxlen){
                        maxlen = lenmal;
                        sum = summal;
                    }
                }else {
                    lenros += 1;
                    lenmal += 1;
                    sumros += liczba2;
                    summal += liczba2;
                    if(lenmal > maxlen){
                        maxlen = lenmal;
                        sum = summal;
                    }
                    if(lenros > maxlen){
                        maxlen = lenros;
                        sum = sumros;
                    }
                }
                liczba1 = liczba2;
            }
            System.out.println(maxlen + " " + sum);

        }catch (IOException e1){
            System.out.println("Blad w pobieraniu pliku");
            e1.printStackTrace();
        }
    }
}