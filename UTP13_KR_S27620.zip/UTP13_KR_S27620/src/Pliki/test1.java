package Pliki;

public class test1 {
    public static final int a = 0;

    public test1(int b) {
        System.out.println(b);
    }

    public void setA(int b) {
        System.out.println(b);
    }
}
