package Pliki;

public class test2 {
    String b;

    public test2(String b) {
        this.b = b;
    }

    public String getB() {
        return b;
    }
}
