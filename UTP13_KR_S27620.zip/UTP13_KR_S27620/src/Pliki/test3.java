package Pliki;

public class test3 extends  test1{

    public static char c;

    public test3(int a, char c) {
        super(a);
        this.c = c;
    }
}
