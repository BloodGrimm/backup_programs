package zad3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.Method;

public class AccountChange implements PropertyChangeListener {
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        double nowa = (double)evt.getNewValue();
        double stara = (double)evt.getOldValue();
        if(nowa < 0){
            System.out.println("2: Value changed from " + stara + " to " + nowa + ", balance < 0!");
        }else {
            System.out.println("Wykonano tranzakcje.");
        }
    }
}
