package zad3;

import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeSupport;

public class Account {

    static int tmp;
    int nrkonta;

    double stankonta;

    PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
    VetoableChangeSupport vetoableChangeSupport = new VetoableChangeSupport(this);


    public Account() {
        this.stankonta = 0;
        tmp += 1;
        nrkonta = tmp;
    }
    public Account(double i) {
        this.stankonta = i;
        tmp += 1;
        nrkonta = tmp;
    }

    public void deposit(double i) throws PropertyVetoException {
        double old = stankonta;
        stankonta += i;
        System.out.println("1: Value changed from " + old + " to " + stankonta);
    }

    public void withdraw(double i) throws PropertyVetoException {
        double old = stankonta;
        vetoableChangeSupport.fireVetoableChange("Veto", stankonta, stankonta - i);
        stankonta -= i;
        propertyChangeSupport.firePropertyChange("Prop", old, stankonta);
    }

    public void transfer(Account acc1, double i) throws PropertyVetoException{
        double old = stankonta;
        vetoableChangeSupport.fireVetoableChange("Veto", stankonta, stankonta - i);
        this.withdraw(i);
        acc1.deposit(i);
    }

    @Override
    public String toString() {
        return "Acc " + nrkonta + ": " + stankonta;
    }
}
