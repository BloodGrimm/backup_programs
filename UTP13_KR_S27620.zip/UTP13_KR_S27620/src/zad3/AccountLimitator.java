package zad3;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;

public class AccountLimitator implements VetoableChangeListener {
    double limit;
    public AccountLimitator(int i) {
        this.limit = i;
    }

    @Override
    public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
        double nowa = (double)evt.getNewValue();
        if(nowa < limit){
            throw new PropertyVetoException("2: Unacceptable value change: " + nowa, evt);
        }

    }
}
