package zad2;

import java.lang.reflect.*;
import Pliki.test3;
import Pliki.test2;
import Pliki.test1;

public class Main2 {
    public static void main(String[] args) {
        try {
            Class c = test3.class;
            if(c.getSuperclass() != null){
                System.out.println("Nadklasa: " + c.getSuperclass().getSimpleName());
            }
            System.out.println("Konstruktory: ");
            Constructor [] constructors = c.getConstructors();
            for (Constructor a: constructors) {
                if(a.getParameterCount() > 1){
                    String odp = "";
                    int mod = a.getModifiers();
                    odp += Modifier.toString(mod) + " ";
                    String name = a.getDeclaringClass().getSimpleName();
                    odp += name + "(";
                    Parameter [] parameters = a.getParameters();
                    for (int f = 0; f < parameters.length; f++) {
                        Parameter b = parameters[f];
                        odp += b.getType().getSimpleName();
                        if(f != parameters.length-1) odp += ", ";
                    }
                    odp += ")";
                    System.out.println(odp);
                }
            }
            System.out.println();
            Method[] methody = c.getDeclaredMethods();
            System.out.println("Metody: ");
            for (Method a: methody) {
                if(!Modifier.isPrivate(a.getModifiers())) {
                    String odp = "";
                    int mod = a.getModifiers();
                    odp += Modifier.toString(mod) + " ";
                    odp += a.getReturnType() + " ";
                    String name = a.getName();
                    odp += name + "(";
                    Parameter [] parameters = a.getParameters();
                    for (int f = 0; f < parameters.length; f++) {
                        Parameter b = parameters[f];
                        odp += b.getType().getSimpleName();
                        if(f != parameters.length-1) odp += ", ";
                    }
                    odp += ")";
                    System.out.println(odp);
                }
            }
            System.out.println();
            System.out.println("Pola: ");
            Field [] fields = c.getDeclaredFields();
            for (Field a: fields) {
                if(Modifier.isPublic(a.getModifiers())){
                    String odp = "";
                    int mod = a.getModifiers();
                    odp += Modifier.toString(mod) + " ";
                    odp += a.getType() + " ";
                    odp += a.getName();
                    System.out.println(odp);

                }
            }
            System.out.println();
            System.out.println("Pola Nadklasy: ");
            if(c.getSuperclass() != null){
                Class b = c.getSuperclass();
                fields = b.getDeclaredFields();
                for (Field a: fields) {
                    if(Modifier.isPublic(a.getModifiers())){
                        String odp = "";
                        int mod = a.getModifiers();
                        odp += Modifier.toString(mod) + " ";
                        odp += a.getType() + " ";
                        odp += a.getName();
                        System.out.println(odp);

                    }
                }
            }
            test3 test3 = new test3(12, 'A');
            test3.setA('b');
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
