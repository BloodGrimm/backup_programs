/**
 *
 *  @author Kłos Radosław S27620
 *
 */

package zad1;


import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

public class Calc {

    Map<String, Method> symbole = new HashMap<>();

    public String doCalc(String arg) {
        try {
            symbole.put("+", BigDecimal.class.getMethod("add", BigDecimal.class, MathContext.class));
            symbole.put("-", BigDecimal.class.getMethod("subtract", BigDecimal.class, MathContext.class));
            symbole.put("*", BigDecimal.class.getMethod("multiply", BigDecimal.class, MathContext.class));
            symbole.put("/", BigDecimal.class.getMethod("divide", BigDecimal.class, MathContext.class));
            String[] data = arg.split(" ");
            String bd1 = data[0];
            String bd2 = data[2];
            String znak = data[1];
            Method metoda = symbole.get(znak);
            BigDecimal wynik = (BigDecimal)metoda.invoke(new BigDecimal(bd1), new BigDecimal(bd2), new MathContext(7));
            return wynik.setScale(7, RoundingMode.HALF_UP).stripTrailingZeros().toString();
        }catch (Exception e){
            e.printStackTrace();
            return "Invalid command to calc";
        }
    }
}
