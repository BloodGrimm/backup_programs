package zadania;

import java.sql.*;

public class Cre1 {

    static public void main(String[] args) {
        new Cre1();
    }

    Statement stmt;
    Connection con = null;
    Cre1() {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String url = "jdbc:derby://localhost:1527/ksidb";
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
            // łączenie z bazą i utworzenie obiektu typu Statement
        } catch (Exception exc) {
            System.out.println(exc);
            System.exit(1);
        }

        // metoda dropTable jest naszą własną metodą napisaną dla skrócenia programu
        // usuwa ona tabelę podaną jako argument
        // Aby w każdych okolicznościach stworzyć nową tabelę AUTOR
        // musimy usunąć ew.  już istniejącą tabelę AUTOR
        dropTable("POZYCJE"); // usunięcie tabeli pochodnej, będącej w relacji z tabelą AUTOR
        dropTable("AUTOR");   // usunięcie tabeli AUTOR

        String crestmt = "CREATE TABLE AUTOR ( AUTID INT PRIMARY KEY, NAME VARCHAR(255) NOT NULL)";

        try {
            stmt.executeUpdate(crestmt);

        } catch (SQLException exc) {                      // przechwycenie wyjątku:
            System.out.println("SQL except.: " + exc.getMessage());
            System.out.println("SQL state  : " + exc.getSQLState());
            System.out.println("Vendor errc: " + exc.getErrorCode());
            System.exit(1);
        } finally {
            try {
                stmt.close();
                con.close();
            } catch (SQLException exc) {
                System.out.println(exc);
                System.exit(1);
            }
        }
    }

    private void dropTable(String tname) {
        try{
            DatabaseMetaData dbm = con.getMetaData();
            ResultSet resultSet = dbm.getTables(null, null, tname.toUpperCase(), null);
            if(resultSet.next()){
                stmt.executeUpdate("DROP TABLE " + tname);
                System.out.println("Usunieto tabele.");
            }else {
                System.out.println("Nie ma tabeli.");
            }
        }catch (SQLException sql){
            sql.printStackTrace();
        }
    }
}