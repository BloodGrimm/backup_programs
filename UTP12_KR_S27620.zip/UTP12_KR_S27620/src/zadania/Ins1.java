package zadania;

import java.sql.*;

public class Ins1 {

    static public void main(String[] args) {
        new Ins1();
    }

    Statement stmt;
    Connection con = null;
    Ins1()  {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String url = "jdbc:derby://localhost:1527/ksidb";
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
        } catch (Exception exc)  {
            System.out.println(exc);
            System.exit(1);
        }
        // nazwy wydawców do wpisywania do tabeli
        String[] wyd =  { "PWN", "PWE", "Czytelnik", "Amber", "HELION", "MIKOM" };

        // pierwszy numer wydawcy do wpisywania do tabeli: PWN ma numer 15, PWE ma 16, ...
        int beginKey = 15;

        String[] ins = new String[wyd.length];
        for (int i = 0; i < wyd.length; i++) {
            ins[i] = "INSERT INTO WYDAWCA (WYDID, NAME) VALUES (" + (beginKey+i) + ", '" + wyd[i] + "')";
        }
        int insCount = 0;   // ile rekordów wpisano
        try  {
            for (int i=0; i < ins.length; i++) {
                insCount += stmt.executeUpdate(ins[i]);
            }
            System.out.println("Wpisanych: " + insCount + " rekordow.");
        }catch (SQLException sql){
            sql.printStackTrace();
        }
        int deleted = 0;
        try  {
            PreparedStatement delete = con.prepareStatement("DELETE FROM WYDAWCA WHERE NAME = ?");
            for (int i=0; i < wyd.length; i++) {
                delete.setString(1, wyd[i]);
                deleted += delete.executeUpdate();
            }
            System.out.println("Usunietych: " + deleted + " rekordow.");
        }catch (SQLException sql){
            sql.printStackTrace();
        }
    }
}