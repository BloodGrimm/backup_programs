package zadania;

import java.sql.*;

public class Sel1 {

    Connection con;

    public static void main(String[] args) {
        new Sel1();
    }
    Sel1() {
        String sel = "SELECT AUTOR.NAME AS \"Nazwisko\", POZYCJE.TYTUL AS \"Tytuł\", POZYCJE.ROK AS \"Rok_wydania\", POZYCJE.CENA AS \"CENA\" FROM POZYCJE JOIN AUTOR ON POZYCJE.AUTID = AUTOR.AUTID WHERE POZYCJE.ROK > 2000 AND POZYCJE.CENA > 30";
        try  {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String url = "jdbc:derby://localhost:1527/ksidb";
            con = DriverManager.getConnection(url);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sel);
            while (rs.next())  {
                String nazwisko = rs.getString("Nazwisko");
                String tytul = rs.getString("Tytuł");
                int rok = rs.getInt("Rok_wydania");
                double cena = rs.getDouble("Cena");
                System.out.println("Autor: " + nazwisko);
                System.out.println("Tytuł: " + tytul);
                System.out.println("Rok wydania: " + rok);
                System.out.println("Cena: " + cena);
            }
        } catch (SQLException exc)  {
            System.out.println(exc.getMessage());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        sel = "SELECT * FROM POZYCJE";
        try  {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sel);
            ResultSetMetaData rsmd = rs.getMetaData();
            int cc = rsmd.getColumnCount();
            for (int i = 1; i <= cc; i++)
                System.out.print(rsmd.getColumnLabel(i) + "     ");

            System.out.println("\n------------------------------ przewijanie do góry");

            rs.afterLast();
            while (rs.previous()){
                for (int i = 1; i <= cc; i++) {
                    System.out.print(rs.getString(i) + ", ");
                }
                System.out.println();
            }
            System.out.println("\n----------------------------- pozycjonowanie abs.");
            int[] poz =  { 3, 7, 9  };
            for (int p = 0; p < poz.length; p++)  {
                System.out.print("[ " + poz[p] + " ] ");
                rs.absolute(poz[p]);
                for (int i = 1; i <= cc; i++) System.out.print(rs.getString(i) + ", ");
                System.out.println("");
            }
            stmt.close();
            con.close();
        } catch (SQLException exc)  {
            System.out.println(exc.getMessage());
        }

    }
}
