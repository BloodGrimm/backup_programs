package zad2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Futil {

    public static File endfile;

    public static void processDir(String dirName, String resultFileName) {
        endfile = new File(resultFileName);
        try {
            FileWriter fileWriter = new FileWriter(endfile);
            File sourceFolder = new File(dirName);
            Path path = sourceFolder.toPath();
            List <Path> data;
            try (Stream<Path> walk = Files.walk(path)) {
                data = walk.filter(Files::isRegularFile)
                        .collect(Collectors.toList());
            }
            for (int i = 0; i < data.size(); i++) {
                System.out.println("visitFile: " + data.get(i));
                List <String> tmp = Files.readAllLines(data.get(i), Charset.forName("Cp1250"));
                for (int j = 0; j < tmp.size(); j++) {
                    fileWriter.append(tmp.get(j));
                    fileWriter.append("\n");
                }
            }
            fileWriter.close();

        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}
