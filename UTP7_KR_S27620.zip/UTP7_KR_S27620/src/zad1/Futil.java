package zad1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;

public class Futil {

    public static File endfile;

    public static void processDir(String dirName, String resultFileName) {
        endfile = new File(resultFileName);
        try {
            FileWriter fileWriter = new FileWriter(endfile);

            Files.walkFileTree(new File(dirName).toPath(), new SimpleFileVisitor<Path>() {

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    System.out.println("visitFile: " + file);
                    List<String> data;
                    data = Files.readAllLines(file, Charset.forName("Cp1250"));
                    for (int i = 0; i < data.size(); i++) {
                        fileWriter.append(data.get(i));
                        fileWriter.append("\n");
                    }

                    return FileVisitResult.CONTINUE;
                }
            });
            fileWriter.close();

        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}
