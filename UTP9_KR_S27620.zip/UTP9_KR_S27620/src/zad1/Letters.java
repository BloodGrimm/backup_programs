package zad1;

import static java.lang.Thread.sleep;
public class Letters{

    String[] letters;
    Thread[] threads;
    public Letters(String input) {
        letters = input.split("");
        threads = new Thread[letters.length];
        for (int i = 0; i < letters.length; i++) {
            int finalI = i;
            threads[i] =  new Thread(()->{
                boolean tmp = true;
                while (tmp) {
                    System.out.print(letters[finalI]);
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        tmp = false;
                    }
                }
            },"Thread " +letters[i]);
        }
    }

    public Thread[] getThreads() {
        return threads;
    }
}
