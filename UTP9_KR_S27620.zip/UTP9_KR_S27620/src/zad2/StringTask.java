package zad2;

public class StringTask implements Runnable{
    String mainstring = "";
    String input;

    State state;

    Thread thread;
    int count;

    public StringTask(String input, int count) {
        this.input = input;
        this.count= count;
        state = State.CREATED;
    }

    @Override
    public void run() {
        state = State.RUNNING;
        for (int i = 0; i < count && state == State.RUNNING; i++) {
            mainstring += input;
        }
        if (state != State.ABORTED)
            state = State.READY;
    }

    public State getState() {
        return state;
    }

    public void start() {
        thread = new Thread(this);
        thread.start();
    }

    public boolean isDone() {
        if(state == State.READY || state == State.ABORTED){
            return true;
        }else {
            return false;
        }
    }

    public String getResult() {
        return mainstring;
    }

    public void abort(){
        state = State.ABORTED;
    }
}
