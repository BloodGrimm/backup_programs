import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.List;

public class Main {
    public static List<String> languages = new ArrayList<>();
    public static LinkedHashMap<String, List<String>> trening = new LinkedHashMap<>();
    public static LinkedHashMap<String, List<String>> test = new LinkedHashMap<>();

    public static double good = 0;
    public static double all = 0;


    public static void main(String[] args) {
        File directorypath = new File("src/Dane_treningowe");
        languages = List.of(directorypath.list());
        for (int i = 0; i < languages.size(); i++){
            String name = languages.get(i);
            File path = Path.of(directorypath + "/" + name).toFile();
            List<String> txtnames = List.of(path.list());
            List <String> txts = new ArrayList<>();
            for (String a: txtnames) {
                try {
                    Scanner scanner = new Scanner(Path.of(directorypath + "/" + name + "/" + a));
                    String content = readAll(scanner);
                    txts.add(content);
                }catch (IOException e){
                    JOptionPane.showMessageDialog(null, "Something is wrong with the files", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            trening.put(name, txts);
        }
        AI ai = new AI(trening, languages, languages.size());
        EventQueue.invokeLater(() -> new GUI(ai));
    }

    public static String readAll(Scanner scanner){
        StringBuilder result = new StringBuilder();
        while (scanner.hasNext()){
            result.append(scanner.nextLine());
        }
        return  result.toString();
    }

    public static void testAI(AI ai){
        File directorypath = new File("src/Dane_testowe");
        languages = List.of(directorypath.list());
        for (int i = 0; i < languages.size(); i++){
            String name = languages.get(i);
            File path = Path.of(directorypath + "/" + name).toFile();
            List<String> txtnames = List.of(path.list());
            List <String> txts = new ArrayList<>();
            for (String a: txtnames) {
                try {
                    Scanner scanner = new Scanner(Path.of(directorypath + "/" + name + "/" + a));
                    String content = readAll(scanner);
                    txts.add(content);
                }catch (IOException e){
                    JOptionPane.showMessageDialog(null, "Something is wrong with the files", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            test.put(name, txts);
        }

        for (Map.Entry<String, List<String>> textList : test.entrySet()) {
            for (String text : textList.getValue()){
                String language = ai.checkLanguage(text);
                if (language.equals(textList.getKey())){
                    good += 1;
                }
                all += 1;
            }
        }
        double wynik = good/all*100;
        JOptionPane.showMessageDialog(null, "Percentage of tests that were done correctly: " + wynik + "%", "test", JOptionPane.INFORMATION_MESSAGE);
    }
}