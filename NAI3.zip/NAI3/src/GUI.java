import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class GUI extends JFrame {

    String text = "";

    public GUI(AI ai) {
        //frame
        this.setSize(new Dimension(600,400));
        //panel
        JPanel whole = new JPanel();
        whole.setBackground(Color.GRAY);
        whole.setLayout(new BorderLayout());
        //textpane
        JPanel panel = new JPanel();
        JTextPane title = new JTextPane();
        title.setText("Wklej tekst poniżej: ");
        Font font = new Font("SansSerif", Font.PLAIN, 30);
        title.setFont(font);
        title.setEnabled(false);
        panel.add(title);
        //Jtextarea
        TextArea write = new TextArea();
        write.setFont(new Font("SansSerif", Font.PLAIN, 20));
        //button
        JButton button = new JButton("Znajdź język");
        ActionListener action = e -> {
            text = write.getText();
            write.setText("");
            setVisible(false);
            String jezyk;
            String blad = JOptionPane.showInputDialog(null, "Proszę podaj błąd: ");
            while(blad == null || blad.isEmpty()){
                blad = JOptionPane.showInputDialog(null, "Proszę podaj błąd: ");
            }
            //perceptrony i logiga
            ai.learnAll(blad);
            jezyk = ai.checkLanguage(text);
            Main.testAI(ai);
            //
            JOptionPane.showMessageDialog(null, "Twój text jest w jezyku: \n" + jezyk, "Wynik", JOptionPane.INFORMATION_MESSAGE);
            setVisible(true);
        };
        button.addActionListener(action);
        button.setFont(new Font("SansSerif", Font.PLAIN, 20));
        //whole
        whole.add(panel, BorderLayout.NORTH);
        whole.add(write, BorderLayout.CENTER);
        whole.add(button, BorderLayout.SOUTH);
        whole.setBorder(BorderFactory.createLineBorder(Color.lightGray,20));
        //frame
        this.add(whole);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
