import javax.swing.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class AI {
    double learningCurve;
    List<Perceptron> perceptronList = new ArrayList<>();
    public AI(LinkedHashMap<String, List<String>> training, List<String> languages, int count) {
        this.learningCurve = Double.parseDouble(JOptionPane.showInputDialog(null, "Proszę podaj próg uczenia: "));
        for (int i = 0; i < count; i++) {
            perceptronList.add(new Perceptron(training, languages, i, learningCurve));
        }
    }

    void learnAll(String blad){
        for (int i = 0; i < perceptronList.size(); i++) {
            Perceptron tmp = perceptronList.get(i);
            tmp.learn(Double.parseDouble(blad));
        }
    }

     public String checkLanguage(String text){
        double[] vector = makeVectors(text);
        double bestresult = -2;
        String bestLanguage = "Angielski";
        for (Perceptron perc : perceptronList){
            double percresult = perc.textResult(vector);
            if(percresult > bestresult){
                bestresult = percresult;
                bestLanguage = perc.learned;
            }
        }
        return bestLanguage;
    }

    public double[] makeVectors(String text){
        int[] lettercount = new int[26];
        int count = 0;
        String tmp = text.toLowerCase();
        for (int i = 0; i < tmp.length(); i++) {
            if(tmp.charAt(i) >= 'a' && tmp.charAt(i) < 'z'){
                lettercount[tmp.charAt(i) - 'a'] += 1;
                count += 1;
            }
        }
        double[] vector = new double[26];
        for (int i = 0; i < lettercount.length; i++) {
            vector[i] = (double) lettercount[i] / count;
        }
        return vector;
    }
}
