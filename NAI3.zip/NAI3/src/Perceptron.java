import java.util.*;

public class Perceptron {

    double learningCurve;
    LinkedHashMap<String, List<String>> training;
    List<String> languages;
    String learned;

    List<double[]> vectors = new ArrayList<>();

    double[] weights = new double[26];

    public Perceptron(LinkedHashMap<String, List<String>> training, List<String> languages, int count, double learningCurve) {
        this.learningCurve = learningCurve;
        this.training = training;
        this.languages = languages;
        this.learned = languages.get(count);
        for (int i = 0; i < 26; i++) {
            weights[i] = 1;
        }
    }

    public void learn(double blad){
        for (Map.Entry<String, List<String>> textList : training.entrySet()) {
            for (String text : textList.getValue()){
                makeVectors(text);
            }
        }
        double currblad = blad + 10;
        while (currblad > blad){
            int counter = 0;
            currblad = 0;
            for (Map.Entry<String, List<String>> textList : training.entrySet()) {
                String language = textList.getKey();
                for (String text : textList.getValue()){
                    double expected;
                    if(Objects.equals(learned, language)){
                        expected = 1;
                    }else{
                        expected = -1;
                    }
                    double resulted = textResult(vectors.get(counter));
                    currblad += Math.abs(resulted-expected);
                    if(expected != resulted){
                        for (int i = 0; i < weights.length; i++) {
                            weights[i] = weights[i] + (expected - resulted)*learningCurve*vectors.get(counter)[i];
                        }
                    }
                    counter += 1;
                }
            }
            currblad = currblad/(currblad+1);
        }

    }

    public double textResult(double[] vector){
        double result = 0;
        for (int i = 0; i < weights.length; i++) {
            result += vector[i] * weights[i];
        }
        return 2*(1/(1 + Math.exp(-result))) - 1;
    }

    public void makeVectors(String text){
        int[] lettercount = new int[26];
        int count = 0;
        String tmp = text.toLowerCase();
        for (int i = 0; i < tmp.length(); i++) {
            if(tmp.charAt(i) >= 'a' && tmp.charAt(i) < 'z'){
                lettercount[tmp.charAt(i) - 'a'] += 1;
                count += 1;
            }
        }
        double[] vector = new double[26];
        for (int i = 0; i < lettercount.length; i++) {
            vector[i] = (double) lettercount[i] / count;
        }
        vectors.add(vector);
    }
}
